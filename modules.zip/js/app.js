// Set the date we're counting down to
var countDownDate = new Date();
var countDown = new Date(countDownDate.getFullYear(), countDownDate.getMonth(), countDownDate.getDate(), countDownDate.getHours(), countDownDate.getMinutes()+30, countDownDate.getSeconds());

//var countDownDate = Math.floor(new Date().getTime() + (new Date().getTime() % 30));
//console.log(countDownDate);
// Update the count down every 1 second
var x = setInterval(function() {

    // Get todays date and time
    var now = new Date().getTime();
    
    // Find the distance between now an the count down date
    var distance = countDown - now;
    
    // Time calculations for days, hours, minutes and seconds
    //var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    //var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
    // Output the result in an element with id="demo"
    document.getElementById("demo").innerHTML = "<h3> Time: " + minutes + ":" + seconds + "s </h3>";
    
    // If the count down is over, write some text 
    if (distance < 0) {
        clearInterval(x);
        document.getElementById("demo").innerHTML = "EXPIRED";
    }
}, 1000);
